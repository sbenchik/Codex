QsciWriter is a basic, SciTE like text editor made with PyQt4 and QScintilla. It is made by Steve Benchik and inspired by  Writer by Peter Goldsborough. 
To run, simply run the executable included in the zip file.
